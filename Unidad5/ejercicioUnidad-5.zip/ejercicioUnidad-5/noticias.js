$(function(){
    $('#tbNoticias').DataTable({

      language: {
        url:"http://cdn.datatables.net/plug-ins/1.10.12/i18n/Spanish.json"
    },
    responsive:true,


      ajax:{
        url:"http://localhost:3002/usuarios/v1/noticias/",
        dataSrc: function(datos){
          
          console.log(datos.noticias2);
          return datos.noticias2;
        }
      },
      columns:[
        {
          data:"title"
        },
        {
          data:"author"
        },

        {
            data:"note"
        },

        {
            data:"date"
        },

        {
            data:"active"
        },

        {
          targets:[0],
          data:"photo",
          render:function(data){
              return '<img height = "50" width = "50" src = "'+ data +'" /> '; 
          }
        },
        {
          data:function(row){
            console.log(row.title)
            var res = `<button id="btnBorrar" class="btn btn-danger btn-xs"
            onclick="borrar('${row.title}')">
            Eliminar
            </button>`;
            return res
          }
        }
      ]
    });
});

function guardar(){
  //  var name = document.getElementById("txtNombre").value;
    var title = $('#txtTitulo').val(); //Jquery referirse a id = #
    //$('#txtNombre').val('Mi nombre');
    var author = $('#txtAutor').val();
    var note = $('#txtNota').val();
    var date = $('#txtFecha').val();
    var active = $('#InputEstado').val();
    var photo = $('#txtFoto').val();



    console.log(title);
    console.log(author);
    console.log(note);
    console.log(date);
    console.log(active);
    console.log(photo);

    $.ajax(
      {
        url:"http://localhost:3002/usuarios/v1/noticias/",
        type:"POST",
        data:{
          title:title,
          author:author,
          note:note,
          date:date,
          active:active,
          photo:photo
        }
      }
    )
    .done(
      function(data){
        alert(JSON.stringify(data));

        $('#txtTitulo').val('');
        $('#txtAutor').val('');
        $('#txtNota').val('');
        $('#txtFecha').val('');
        $('#InputEstado').val('');
        $('#txtFoto').val('');

        $('#tbNoticias').dataTable().api().ajax.reload();
      }
    )
    .fail(
      function(err){
        alert(err);
      }
    );
   
}

function borrar(title){
  $.ajax({
    url:"http://localhost:3002/usuarios/v1/noticias/"+title,
    type: "delete"
  })
  .done(
    function(data){
      alert (data.msg);
      $('#tbNoticias').dataTable().api().ajax.reload();
    }
  )
  .fail(
    function(err){
      alert(err);
    }
  )
}